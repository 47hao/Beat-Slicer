BEAT SLICER
by Andrew Zhao
A block slicing rhythm game, where players use motion tracking controls to swing their arms 
and slash through cubes that fly towards them in lanes, all in rhythm with music.

SETUP
Sound files are missing; they are about 151MB, download them from drive and put them
inside the FINAL folder. So FINAL/sounds/music/Radioactive.wav, for example, is correct.
https://drive.google.com/file/d/1zSYIEpJz2JDPvVLKu_Jnv3UYLuUZL6VH/view?usp=sharing

After that, simply run 'game.py' in FINAL

LIBRARIES
- cmu_112_graphics
- openCV
- pyAudio
- numpy
- scipy
- PIL

SHORTCUT COMMANDS
None